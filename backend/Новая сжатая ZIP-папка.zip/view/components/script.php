<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAo_FkCsKwfbxhVNweaqqJ8eQGHucub5Gs&libraries=places&language=en"></script>
<script>
    const SESSION_ID = <?= $_SESSION['user']['user_id'] ? $_SESSION['user']['user_id'] : 'null' ?>;
</script>
<script src="/view/static/js/all.js" defer></script>