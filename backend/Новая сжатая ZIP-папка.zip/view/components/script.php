<!-- <script src="//maps.googleapis.com/maps/api/js?key=api_key&libraries=places&callback=initMap"></script> -->
<script src="/view/static/js/script.js" defer></script>