<?

class ApplicationController {
    
}

?>