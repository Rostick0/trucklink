<?

session_start();

?>