<?

require_once './api/vars.php';
require_once './api/functions.php';
require_once './api/router.php';

?>