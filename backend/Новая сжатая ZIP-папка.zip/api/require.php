<?

require_once __DIR__ . '/vars.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/router.php';

?>