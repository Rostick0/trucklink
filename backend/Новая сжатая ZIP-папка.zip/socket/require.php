<?

mb_internal_encoding("UTF-8");

require_once __DIR__ . '/../include/connect.php';

require_once __DIR__ . '/../global/functions.php';

require_once __DIR__ . '/../model/online.php';

require_once __DIR__ . '/../model/message.php';
require_once __DIR__ . '/../controller/message.php';

require_once __DIR__ . './../vendor/autoload.php';

?>